<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Can_i_get_permits extends MY_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('email_model');
    }

    public function index()
    {
        $data = array();
        $data['tab'] = 1;
        $data['title'] = "Can I Get Permits";
        $this->load->view('include/header');
        $this->load->view('canigetpermit/index', $data);
        $this->load->view('include/footer');
    }

    public function can_i_get_route_ajax_form()
    {
        $data = array();
        $postdata = $this->input->post();
        $data['tab'] = $postdata['tabId'];
        $this->load->view('include/ajax_permit_form', $data);
    }
    function num_cond($var1, $op, $var2)
    {

        switch ($op) {
            case "=":
                return $var1 == $var2;
            case "!=":
                return $var1 != $var2;
            case ">=":
                return $var1 >= $var2;
            case "<=":
                return $var1 <= $var2;
            case ">":
                return $var1 >  $var2;
            case "<":
                return $var1 <  $var2;
            default:
                return true;
        }
    }
    public function can_i_get_permit_calculation()
    {
        $postdata = $this->input->post();
        $tab = $postdata['tab_id'];
        $axle_weight_sum = 0;
        $axle_width_sum = 0;
        $steering_axle_weight_sum = 0;
        $name_attribute = !empty($tab) && $tab == 1 ? "tandem_axles" : ($tab == 2 ? "tridem_axles" : ($tab == 3 ? "tandem_axles" : ($tab == 4 ? "tridem_axles" : ($tab == 5 ? "quad_axles" : "5_axles"))));

        if (!empty($name_attribute)) {
            $t_axle2_weight = !empty($postdata[$name_attribute . "_axle2_weight"]) ? $postdata[$name_attribute . "_axle2_weight"] : 0;
            $t_axle3_weight = !empty($postdata[$name_attribute . "_axle3_weight"]) ? $postdata[$name_attribute . "_axle3_weight"] : 0;
            $t_axle_4_weight = !empty($postdata[$name_attribute . "_axle_4_weight"]) ? $postdata[$name_attribute . "_axle_4_weight"] : 0;
            $t_axle_5_weight = !empty($postdata[$name_attribute . "_axle_5_weight"]) ? $postdata[$name_attribute . "_axle_5_weight"] : 0;
            $t_axle_6_weight = !empty($postdata[$name_attribute . "_axle_6_weight"]) ? $postdata[$name_attribute . "_axle_6_weight"] : 0;
            $axle_weight_sum = $t_axle2_weight + $t_axle3_weight + $t_axle_4_weight + $t_axle_5_weight + $t_axle_6_weight;

            $t_axle2_width = !empty($postdata[$name_attribute . "_axle2_width"]) ? $postdata[$name_attribute . "_axle2_width"] : 0;
            $t_axle3_width = !empty($postdata[$name_attribute . "_axle3_width"]) ? $postdata[$name_attribute . "_axle3_width"] : 0;
            $t_axle_4_width = !empty($postdata[$name_attribute . "_axle_4_width"]) ? $postdata[$name_attribute . "_axle_4_width"] : 0;
            $t_axle_5_width = !empty($postdata[$name_attribute . "_axle_5_width"]) ? $postdata[$name_attribute . "_axle_5_width"] : 0;
            $t_axle_6_width = !empty($postdata[$name_attribute . "_axle_6_width"]) ? $postdata[$name_attribute . "_axle_6_width"] : 0;
            $axle_width_sum = $t_axle2_width + $t_axle3_width + $t_axle_4_width + $t_axle_5_width + $t_axle_6_width;


            #steering axle 
            $steering_axle_weight_1 = !empty($postdata['steering_axle_weight_1']) ? $postdata['steering_axle_weight_1'] : 0;
            $steering_axle_2_weight = !empty($postdata['steering_axle_2_weight']) ? $postdata['steering_axle_2_weight'] : 0;
            $xcp_steer_axle_lb = $steering_axle_weight_1 +  $steering_axle_2_weight;
        }

        $data = array();
        $data['permit_calculation'] = read_data("xcmg_permit_calculation", "xcp_id", "DESC");
        $response = array();
        foreach ($data['permit_calculation'] as $calculation) {
            if (
                !empty($calculation['xcp_width_limit_ft']) &&
                num_condition_operator($calculation['xcp_width_limit_ft'], $calculation['xcp_width_rule_operator'], $postdata['width'])
            ) {

                if (array_key_exists($calculation['xcp_state_id'], $calculation)) { //check date exist 
                    $state_list = $this->db->get_where('xcmg_state', array('state_id' => $calculation['xcp_state_id']))->row();
                    $response[$calculation['xcp_state_id']]['state_id'] = $calculation['xcp_state_id'];
                    $response[$calculation['xcp_state_id']]['state_name'] = $state_list->state_name;
                    $response[$calculation['xcp_state_id']]['permit_required'] = "YES";
                    $response[$calculation['xcp_state_id']]['state_code'] = $state_list->state_code;
                    $response[$calculation['xcp_state_id']]['permit_type'] = $calculation['xcp_permit_type_id'];
                    $response[$calculation['xcp_state_id']]['calculation'][]  =  $calculation;
                    // $response[$calculation['xcp_state_id']][]  =  $calculation;
                } else {
                    $state_l = $this->db->get_where('xcmg_state', array('state_id' => $calculation['xcp_state_id']))->row();
                    $response[$calculation['xcp_state_id']]['state_id'] = $calculation['xcp_state_id'];
                    $response[$calculation['xcp_state_id']]['state_name'] = $state_l->state_name;
                    $response[$calculation['xcp_state_id']]['permit_required'] = "YES";
                    $response[$calculation['xcp_state_id']]['state_code'] = $state_l->state_code;
                    $response[$calculation['xcp_state_id']]['permit_type'] = $calculation['xcp_permit_type_id'];
                    $response[$calculation['xcp_state_id']]['calculation'][]  =  $calculation;
                    // $response[$calculation['xcp_state_id']][]  =  $calculation;
                }

                // $response[] = $calculation;
            } else {
                // if($calculation['xcp_permit_type_id']==17){
                //     $response[$calculation['xcp_state_id']]['anuual'] = "Yes";
                //     $response[$calculation['xcp_state_id']]['permit_required'] = "YES";
                //     // echo "annual permit required";echo "<br>";
                // }else{
                   
                    if (array_key_exists($calculation['xcp_state_id'], $calculation)) { //check date exist 
                        $state_list = $this->db->get_where('xcmg_state', array('state_id' => $calculation['xcp_state_id']))->row();
                        $response[$calculation['xcp_state_id']]['state_id'] = $calculation['xcp_state_id'];
                        $response[$calculation['xcp_state_id']]['permit_required'] = "NO";
                        $response[$calculation['xcp_state_id']]['anuual'] = "NO";
                        $response[$calculation['xcp_state_id']]['state_name'] = $state_list->state_name;
                        $response[$calculation['xcp_state_id']]['state_code'] = $state_list->state_code;
                        $response[$calculation['xcp_state_id']]['permit_type'] = $calculation['xcp_permit_type_id'];
                        $response[$calculation['xcp_state_id']]['calculation'][]  =  $calculation;
                        // $response[$calculation['xcp_state_id']][]  =  $calculation;
                    } else {
                        $state_l = $this->db->get_where('xcmg_state', array('state_id' => $calculation['xcp_state_id']))->row();
                        $response[$calculation['xcp_state_id']]['state_id'] = $calculation['xcp_state_id'];
                        $response[$calculation['xcp_state_id']]['permit_required'] = "NO";
                        $response[$calculation['xcp_state_id']]['anuual'] = "NO";
                        $response[$calculation['xcp_state_id']]['state_name'] = $state_l->state_name;
                        $response[$calculation['xcp_state_id']]['state_code'] = $state_l->state_code;
                        $response[$calculation['xcp_state_id']]['permit_type'] = $calculation['xcp_permit_type_id'];
                        $response[$calculation['xcp_state_id']]['calculation'][]  =  $calculation;
                        // $response[$calculation['xcp_state_id']][]  =  $calculation;
                    }
                // }
                
            }
        }
        $data['response'] = $postdata['width'];
        $data['response'] = $response;
        // pre($data['response']);die;

        $result = $this->load->view('canigetpermit/state_permit', $data, true);
        echo json_encode(array('status' => true, "result" => $result, 'message' => '<div class="alert alert-success">See your filterd resultt</div>'));
        die;
    }

    public function getAddress()
    {
        $RG_Lat = 100.753;
        $RG_Lon = 13.69362;

        $json = "https://nominatim.openstreetmap.org/reverse?format=json&lat=" . $RG_Lat . "&lon=" . $RG_Lon . "&zoom=27&addressdetails=1";

        $ch = curl_init($json);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:59.0) Gecko/20100101 Firefox/59.0");
        $jsonfile = curl_exec($ch);
        curl_close($ch);

        $RG_array = json_decode($jsonfile, true);
        pre($RG_array);
        die;
        //   return $RG_array['display_name'];


        // $RG_array['address']['city'];
        // $RG_array['address']['country'];
    }


    public function test()
    {

        $from = str_replace(" ", "%20", "Himachal Pradesh, India");  //first remove param,second paras add param
        $to = str_replace(" ", "%20", "Prem Mandir Vrindavan, Vrindavan, Uttar Pradesh, India");  //first remove param,second paras add param
        // $from=str_replace(" ","%20","Washington, United States");  //first remove param,second paras add param
        // $to=str_replace(" ","%20","New York, New York, United States");  //first remove param,second paras add param
        $result = json_decode(get_location_by_address($from, $to), true);
        pre(get_location_by_address($from, $to));
        die;
        // pre(get_location_by_address($from,$to));die;
        $actualEnd = $result['resourceSets'][0]['resources'][0]['routeLegs'][0]['actualEnd'];
        $actualStart = $result['resourceSets'][0]['resources'][0]['routeLegs'][0]['actualStart'];
        // $data=get_location_by_address($from,$to);

        // pre($result['resourceSets'][0]['resources'][0]['routeLegs'][0]['itineraryItems']);die;
        $fil = array_column($result['resourceSets'][0]['resources'][0]['routeLegs'][0]['itineraryItems'], 'details');
        foreach ($fil as $f) {
            pre(array_column($f, "names"));
        }
    }
}
