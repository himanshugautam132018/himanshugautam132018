<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Route_permit extends MY_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('email_model');
    }

    public function index()
    {
        $data = array();
        $data['title'] = "Can I Get Permits";
        $this->load->view('include/header');
        $this->load->view('routePermit/index', $data);
        $this->load->view('include/footer');
    }
    public function xcmg_route_permit_form_append()
    {
        $data = array();
        $postdata = $this->input->post();
        $data['tab'] = $postdata['tabId'];
        $this->load->view('include/ajax_permit_form', $data);
    }

    #==================================== Search route by address======================================>
    public function search_route_by_address()
    {
        $postdata = $this->input->post();
        pre($postdata);
    }
    #====================================End Search route by address======================================>
}
