<div class="" id="v-pills-statepermit">
    <h2 class="heading_custom_bottom">State Permit</h2>
    <table class="state_permit">
        <tr>
           
            <?php

            // $calculation_permit = array_column($response, 'calculation');
            $state_id = array_column($response, 'state_id');
            foreach ($state_id as $s) {
                $state_list_row = read_data_where("xcmg_permit_calculation", array("xcp_state_id" => $s));
                $permitTYpe = array_column($state_list_row, 'xcp_permit_type_id');
                foreach ($permitTYpe as $p) {
                    $get_permit_type_data = read_data_where_row("xcmg_permit_type", array("permit_id" => $p));
                    $permit[] = array(
                        "permit_id" => $get_permit_type_data->permit_id,
                        "permit_type" => $get_permit_type_data->permit_type,
                        "xcp_state_id" => $s,
                    );
                }
            }
            
           if(!empty($permit)){ ?>
            <th>State</th>
               <?php foreach ($permit as $per) {
            ?>
                <th><?php echo ucfirst($per['permit_type']); ?></th>
            <?php
            }
        }
            ?>
        </tr>
        <?php if (!empty($response)) {

            foreach ($response as $response_data) {

                foreach ($response_data['calculation'] as $res) {
                    
                    $calculation_data['xcp_permit_type_id']=$res['xcp_permit_type_id'];
                    $calculation_data['xcp_state_id']=$res['xcp_state_id'];
                    $permitT[] =  $calculation_data;
                }

                foreach($permitT as $pt){
                  $xcp_permit_type_id[]=  $pt['xcp_permit_type_id'];
                  $xcp_state_id[]=  $pt['xcp_state_id'];
                }
        ?>
                <tr id="warning_permit">

                    <td><?php echo ucfirst($response_data['state_name']); ?></td>

                    <?php foreach ($permit as $val) {
                        if ($response_data['state_id']==$val['xcp_state_id'] && in_array($val['permit_id'], $xcp_permit_type_id)){
                            $rquire_permit="Permit Availbale";
                        }else{
                            $rquire_permit="No Permit Needed";
                        }
                    ?>
                        <td><?php echo $rquire_permit; ?></td>
                    <?php } ?>
                </tr>
            <?php
                // }
            }
        } else { ?>
            <tr id="warning_permit">
                <td colspan="4" style="text-align:center">No Match result found !!!</td>
            </tr>
        <?php } ?>

    </table>

</div>