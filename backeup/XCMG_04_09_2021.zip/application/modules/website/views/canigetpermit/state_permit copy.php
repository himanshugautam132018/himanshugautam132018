<div class="" id="v-pills-statepermit">
    <h2 class="heading_custom_bottom">State Permit</h2>
    <table class="state_permit">
        <tr>
            <th>State</th>
            <?php
           
            // $calculation_permit = array_column($response, 'calculation');
            $state_id = array_column($response, 'state_id');
            foreach ($state_id as $s){
                $state_list_row=read_data_where("xcmg_permit_calculation",array("xcp_state_id"=>$s));
                $permitTYpe = array_column($state_list_row, 'xcp_permit_type_id');
                foreach ($permitTYpe as $p){
                    $get_permit_type_data=read_data_where_row("xcmg_permit_type", array("permit_id" => $p));
                    $permit[]=array(
                        "permit_id"=>$get_permit_type_data->permit_id,
                        "permit_type"=>$get_permit_type_data->permit_type,
                    );
                }
            }
            // pre($permit);
            // pre(count($permit));
           
            // $calculation_permit = array_column($response, 'calculation');
            // foreach ($calculation_permit as $cal) {
            //     foreach ($cal as $c) {
                    
            //         $get_permit = read_data_where_row("xcmg_permit_type", array("permit_id" => $c['xcp_permit_type_id']));
            foreach ($permit as $per) {
            ?>
                    <th><?php echo ucfirst($per['permit_type']); ?></th>
            <?php 
            }
            // } }
             
            ?>
            <!-- <th>Require Permit?</th>
            <th>Annual Permit</th>
            <th>Violation</th> -->
        </tr>
        <?php if (!empty($response)) {
           pre($response);
            foreach ($response as $response_data) {
                
                foreach ($response_data['calculation'] as $res) {
                    
                  $permitT[]= $res['xcp_permit_type_id'] ;
                }
                
                //     $get_truck_type = read_data_where_row("xcmg_truck_type", array("xcmg_truck_type_id" => $res['xcp_truck_type_id']));
                //     $get_permit_type = read_data_where_row("xcmg_permit_type", array("permit_id" => $res['xcp_permit_type_id']));
                //     $get_permit_type_value=!empty($get_permit_type)?"Yes":"No";
                  
        ?>
                    <tr id="warning_permit">
                       
                        <td><?php echo ucfirst($response_data['state_name']); ?></td>
                        <td><?php echo "Yes"; ?></td>
                        <td>Annual Permit Available</td>
                        <td></td>
                    </tr>
            <?php 
            // }
            }
        } else { ?>
            <tr id="warning_permit">
                <td colspan="4" style="text-align:center">No Match result found !!!</td>
            </tr>
        <?php } ?>

    </table>

    <!-- <button type="submit" class="btn form_button simple_btn previous">Previous</button> -->
</div>