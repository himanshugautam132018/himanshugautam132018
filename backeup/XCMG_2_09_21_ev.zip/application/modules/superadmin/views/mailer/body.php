<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<table  style="font-family: Verdana, Geneva, sans-serif; width:800px; margin:0 auto;" cellpadding="0" cellspacing="0">
		<tr>
			<td style="padding:35px 15px 15px 15px">
				<div style="font-size: 18px;line-height:25px; text-align:justify;">
			    	<p><?=$msg?></p>
			    </div>
				</td>
			</tr>
			
			<tr>
				<td style="padding:35px 15px">
					<div style="font-size:18px; font-weight:600; color:#000;">Thanks</div>
					<div style="font-size:16px; font-weight:300; padding-top:5px; color:#000;">XCMG ARC Team</div>
					<div style="font-size:16px; font-weight:300; padding-top:5px; color:#000;">32 Dora Creek, tuntable creek, New South Wales 2480, Australia.</div>
					<div style="font-size:16px; font-weight:300; padding-top:5px; color:#000;"><a style="color:black; text-decoration:none;" href="mailto:sample@yourdomain.com">sample@yourdomain.com</a></div>
					<div style="font-size:16px; font-weight:300; padding-top:5px; color:#000;"><a style="color:black; text-decoration:none;" href="callto:+088 234 432 15565">+088 234 432 15565</a></div>
				</td>
			</tr>
		</table>