<div class="wrapper" style="width:100%;">
	<div class="container">
		<div style="border: #004c97 solid 1px;; width: 800px; margin: auto;">
				<table style="background-color: white; font-family: Verdana, Geneva, sans-serif; width:800px; margin:0 auto;" cellpadding="0" cellspacing="0">
					<thead>
						<tr>
							<td colspan="3" style="padding: 12px; text-align: center; color: black;
							font-size: 26px; font-weight: 600;"><img width="50%" src="<?=base_url()?>assets/image/logo.png"></td>
						</tr>
						<tr>
						<td style=" border-bottom:#004c97 solid 1px; padding:0 15px 5px 0 ; font-size: 13px; color: #fff; line-height:20px; width:30%">
							</td>
						</tr>
						
						</thead>
					</table>