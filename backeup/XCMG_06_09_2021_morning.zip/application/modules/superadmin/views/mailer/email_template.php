<?php
	$this->load->view('mailer/header');
	$this->load->view('mailer/body');
	$this->load->view('mailer/footer');
?>