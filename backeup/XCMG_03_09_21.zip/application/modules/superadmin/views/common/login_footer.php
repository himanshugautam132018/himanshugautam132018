<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
  
  <script src="<?php echo base_url();?>backend/assets/js/tooltips.js"></script>
  <!-- <script src="assets/vendors/js/vendor.bundle.base.js"></script> -->
  <script src="<?php echo base_url();?>backend/assets/vendors/datatables.net/jquery.dataTables.js"></script>
  <script src="<?php echo base_url();?>backend/assets/vendors/datatables.net-bs4/dataTables.bootstrap4.js"></script>
  <script src="<?php echo base_url();?>backend/assets/vendors/chart.js/Chart.min.js"></script>

  <script src="<?php echo base_url();?>backend/assets/js/off-canvas.js"></script>
  <script src="<?php echo base_url();?>backend/assets/js/hoverable-collapse.js"></script>
  <script src="<?php echo base_url();?>backend/assets/js/misc.js"></script>
  <script src="<?php echo base_url();?>backend/assets/js/jquery-ui.js"></script>
  <script src="<?php echo base_url();?>backend/assets/js/data-table.js"></script>
  <script src="<?php echo base_url();?>backend/assets/js/file-upload.js"></script>
  <script src="<?php echo base_url();?>backend/assets/js/apexcharts.js"></script>
  <script src="<?php echo base_url();?>backend/assets/js/custom.js"></script>

</body>

</html>