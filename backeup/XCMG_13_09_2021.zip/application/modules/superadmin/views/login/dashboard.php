<!DOCTYPE html>

<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
          
                <div class="content-wrapper main_dahsboard d-flex justify-content-center align-items-center">

                    <div class="text-center">
                        <h2>Welcome To <br><span style="font-size: 36px; display: inline-block; color: #e57574;">XCMG ARC </span></h2>
                    </div>
                
                </div>
                
               

       